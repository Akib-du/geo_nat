# GeoLite Native (Android)
Kotlin + Jetpack Compose + MapLibre Native. Open in Android Studio and sync (it creates the Gradle wrapper).
Not yet compiled by the author: expect small first-sync fixes.

## Phase 1 (done)
- Menu bar: Map | Layout | Analysis | Edit
- Map > Add data: Shapefile (.zip or .shp), GPX, GeoJSON, raster MBTiles
- Map > Basemap: none / OpenStreetMap / Imagery (Esri) / offline MBTiles
- Map > Identify, Select, Clear selection
- Placemark button: GPS location (asks permission), map centre, or tap on map
- Project persistence

## Phase 2 (this build): editing
Edit menu. Pick an **edit layer** first (Edit > Edit layer), or create one.
- Create feature class: name + Point / LineString / Polygon
- Add feature: tap vertices on the map (Undo / Finish for lines and polygons)
- Modify feature: tap a feature, tap one of its vertices (blue dots), tap the new position
- Attribute table: full-screen; tap a cell to edit; tick rows to select; Select all
- Add field (text / integer / double); Populate field (constant, row number, copy field,
  area m2, length m, X, Y; selected features or all)
- Delete selected features (select with Map > Select or by ticking rows in the table)
- Features now have stable ids ("f1", "f2", ...); fields and geometry type are saved with the project

## Roadmap
3. Vector Analysis toolbox with JTS + proj4j: clip, buffer, merge, reprojection, layer to KML, KML to layer
4. Rasters: GeoTIFF + FileGDB import (needs GDAL native libs), raster calculator, raster clip, raster to polygon, polygon to raster
5. Layout: map frame, elements (title, legend, scale bar with divisions, north arrow), properties, PDF/PNG export

## Known limits
- No undo for edits; each edit rewrites the whole layer JSON (fine for thousands of features, slow for hundreds of thousands)
- Modify moves one vertex at a time; no add/delete vertex yet
- Area/length are spherical approximations on lon/lat data
- Shapefile CRS is assumed lon/lat until the Reprojection tool exists
- Vector MBTiles unsupported
