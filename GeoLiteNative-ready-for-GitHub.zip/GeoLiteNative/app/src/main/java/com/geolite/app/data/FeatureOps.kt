package com.geolite.app.data

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

enum class PopMode(val label: String) {
    CONSTANT("Constant value"), ROW_NUMBER("Row number"), COPY_FIELD("Copy from field"),
    AREA("Area (m²)"), LENGTH("Length (m)"), X("X (lon, or bbox centre)"), Y("Y (lat, or bbox centre)")
}

/** Pure functions over a GeoJSON FeatureCollection string. Each edit re-serialises the layer (fine for moderate sizes). */
object FeatureOps {
    const val EMPTY = """{"type":"FeatureCollection","features":[]}"""
    private const val R = 6378137.0

    private fun feats(o: JSONObject) = o.getJSONArray("features")
    private fun idOf(f: JSONObject) = f.opt("id")?.toString()
    private fun rad(d: Double) = d * PI / 180

    private fun nextId(a: JSONArray): Int {
        var m = 0
        for (i in 0 until a.length()) {
            val id = idOf(a.getJSONObject(i)) ?: continue
            if (id.startsWith("f")) id.drop(1).toIntOrNull()?.let { m = max(m, it) }
        }
        return m + 1
    }

    fun count(fc: String) = feats(JSONObject(fc)).length()

    /** Gives every feature a string id and a properties object. */
    fun prepare(fc: String): String {
        val o = JSONObject(fc); val a = feats(o); var next = nextId(a)
        for (i in 0 until a.length()) {
            val f = a.getJSONObject(i)
            if (!f.has("id") || f.isNull("id")) f.put("id", "f${next++}") else f.put("id", f.get("id").toString())
            if (f.optJSONObject("properties") == null) f.put("properties", JSONObject())
        }
        return o.toString()
    }

    fun inferFields(fc: String): List<Field> {
        val a = feats(JSONObject(fc)); val types = LinkedHashMap<String, FieldType?>()
        for (i in 0 until a.length()) {
            val p = a.getJSONObject(i).optJSONObject("properties") ?: continue
            for (k in p.keys()) {
                val v = p.get(k)
                if (v == JSONObject.NULL) { if (!types.containsKey(k)) types[k] = null; continue }
                val t = when (v) { is Int, is Long -> FieldType.INTEGER; is Number -> FieldType.DOUBLE; else -> FieldType.TEXT }
                val old = types[k]
                types[k] = when {
                    old == null || old == t -> t
                    old == FieldType.TEXT || t == FieldType.TEXT -> FieldType.TEXT
                    else -> FieldType.DOUBLE
                }
            }
        }
        return types.map { Field(it.key, it.value ?: FieldType.TEXT) }
    }

    fun inferGeometryType(fc: String): String {
        val a = feats(JSONObject(fc)); val kinds = HashSet<String>()
        for (i in 0 until a.length()) a.getJSONObject(i).optJSONObject("geometry")?.optString("type")?.removePrefix("Multi")?.let { kinds.add(it) }
        return if (kinds.size == 1) kinds.first() else if (kinds.isEmpty()) "Mixed" else "Mixed"
    }

    fun blankProps(fields: List<Field>) = JSONObject().also { p -> fields.forEach { p.put(it.name, JSONObject.NULL) } }

    fun addFeature(fc: String, geom: JSONObject, props: JSONObject): String {
        val o = JSONObject(fc); val a = feats(o)
        a.put(JSONObject().put("type", "Feature").put("id", "f${nextId(a)}").put("geometry", geom).put("properties", props))
        return o.toString()
    }

    fun addField(fc: String, f: Field): String {
        val o = JSONObject(fc); val a = feats(o)
        for (i in 0 until a.length()) a.getJSONObject(i).getJSONObject("properties").let { if (!it.has(f.name)) it.put(f.name, JSONObject.NULL) }
        return o.toString()
    }

    fun setValue(fc: String, fid: String, f: Field, text: String): String {
        val o = JSONObject(fc); val a = feats(o)
        for (i in 0 until a.length()) {
            val ft = a.getJSONObject(i)
            if (idOf(ft) == fid) { ft.getJSONObject("properties").put(f.name, coerce(f.type, text.ifBlank { null })); break }
        }
        return o.toString()
    }

    fun delete(fc: String, ids: Set<String>): String {
        val o = JSONObject(fc); val a = feats(o); val keep = JSONArray()
        for (i in 0 until a.length()) { val f = a.getJSONObject(i); if (idOf(f) !in ids) keep.put(f) }
        return o.put("features", keep).toString()
    }

    fun getMany(fc: String, ids: Collection<String>): List<JSONObject> {
        val a = feats(JSONObject(fc)); val want = ids.toSet(); val out = ArrayList<JSONObject>()
        for (i in 0 until a.length()) { val f = a.getJSONObject(i); if (idOf(f) in want) out.add(f) }
        return out
    }

    /** (id, properties) per feature, for the attribute table. */
    fun rows(fc: String): List<Pair<String, JSONObject>> {
        val a = feats(JSONObject(fc))
        return (0 until a.length()).map { a.getJSONObject(it).let { f -> (idOf(f) ?: "") to (f.optJSONObject("properties") ?: JSONObject()) } }
    }

    // ----- geometry -----
    private fun posLists(a: JSONArray, f: (JSONArray) -> Unit) {
        if (a.length() > 0 && a.opt(0) is JSONArray && a.getJSONArray(0).opt(0) is Number) f(a)
        else for (i in 0 until a.length()) (a.opt(i) as? JSONArray)?.let { posLists(it, f) }
    }

    fun vertices(g: JSONObject): List<DoubleArray> {
        val out = ArrayList<DoubleArray>()
        val c = g.optJSONArray("coordinates") ?: return out
        if (g.optString("type") == "Point") out.add(doubleArrayOf(c.getDouble(0), c.getDouble(1)))
        else posLists(c) { l -> for (i in 0 until l.length()) l.getJSONArray(i).let { out.add(doubleArrayOf(it.getDouble(0), it.getDouble(1))) } }
        return out
    }

    /** Moves vertex number [index] (order of [vertices]); a ring's duplicate closing vertex moves with it. */
    fun moveVertex(fc: String, fid: String, index: Int, lon: Double, lat: Double): String {
        val o = JSONObject(fc); val a = feats(o)
        for (i in 0 until a.length()) {
            val f = a.getJSONObject(i)
            if (idOf(f) != fid) continue
            val g = f.optJSONObject("geometry") ?: break
            val c = g.optJSONArray("coordinates") ?: break
            if (g.optString("type") == "Point") { c.put(0, lon); c.put(1, lat) }
            else {
                var run = 0
                posLists(c) { l ->
                    val n = l.length()
                    if (index >= run && index < run + n) {
                        val old = l.getJSONArray(index - run); val ox = old.getDouble(0); val oy = old.getDouble(1)
                        for (k in 0 until n) l.getJSONArray(k).let { p -> if (p.getDouble(0) == ox && p.getDouble(1) == oy) { p.put(0, lon); p.put(1, lat) } }
                    }
                    run += n
                }
            }
            break
        }
        return o.toString()
    }

    private fun ringArea(l: JSONArray): Double {
        var s = 0.0
        for (i in 0 until l.length() - 1) {
            val p = l.getJSONArray(i); val q = l.getJSONArray(i + 1)
            s += (rad(q.getDouble(0)) - rad(p.getDouble(0))) * (2 + sin(rad(p.getDouble(1))) + sin(rad(q.getDouble(1))))
        }
        return abs(s * R * R / 2)
    }
    private fun polyArea(rings: JSONArray): Double {
        var a = 0.0
        for (i in 0 until rings.length()) a += ringArea(rings.getJSONArray(i)) * (if (i == 0) 1 else -1)
        return a
    }
    fun area(g: JSONObject): Double {
        val c = g.optJSONArray("coordinates") ?: return 0.0
        return when (g.optString("type")) {
            "Polygon" -> polyArea(c)
            "MultiPolygon" -> (0 until c.length()).sumOf { polyArea(c.getJSONArray(it)) }
            else -> 0.0
        }
    }
    private fun hav(p: JSONArray, q: JSONArray): Double {
        val dLat = rad(q.getDouble(1) - p.getDouble(1)); val dLon = rad(q.getDouble(0) - p.getDouble(0))
        val h = sin(dLat / 2).pow(2) + cos(rad(p.getDouble(1))) * cos(rad(q.getDouble(1))) * sin(dLon / 2).pow(2)
        return 2 * R * asin(min(1.0, sqrt(h)))
    }
    fun length(g: JSONObject): Double {
        val c = g.optJSONArray("coordinates") ?: return 0.0
        if (g.optString("type") == "Point") return 0.0
        var d = 0.0
        posLists(c) { l -> for (i in 0 until l.length() - 1) d += hav(l.getJSONArray(i), l.getJSONArray(i + 1)) }
        return d
    }
    private fun center(g: JSONObject): DoubleArray? {
        val v = vertices(g); if (v.isEmpty()) return null
        return doubleArrayOf((v.minOf { it[0] } + v.maxOf { it[0] }) / 2, (v.minOf { it[1] } + v.maxOf { it[1] }) / 2)
    }

    private fun coerce(type: FieldType, v: Any?): Any {
        if (v == null || v == JSONObject.NULL) return JSONObject.NULL
        val d = (v as? Number)?.toDouble() ?: v.toString().trim().toDoubleOrNull()
        return when (type) {
            FieldType.INTEGER -> if (d != null && d.isFinite()) d.roundToLong() else JSONObject.NULL
            FieldType.DOUBLE -> if (d != null && d.isFinite()) d else JSONObject.NULL
            FieldType.TEXT -> if (v is Double) (if (v == floor(v) && abs(v) < 1e15) v.toLong().toString() else v.toString()) else v.toString()
        }
    }

    /** Fills [field] for the given feature ids (null = all features). */
    fun populate(fc: String, field: Field, mode: PopMode, arg: String, ids: Set<String>?): String {
        val o = JSONObject(fc); val a = feats(o)
        for (i in 0 until a.length()) {
            val f = a.getJSONObject(i)
            if (ids != null && (idOf(f) ?: "") !in ids) continue
            val props = f.getJSONObject("properties"); val g = f.optJSONObject("geometry")
            val v: Any? = when (mode) {
                PopMode.CONSTANT -> arg
                PopMode.ROW_NUMBER -> (i + 1).toLong()
                PopMode.COPY_FIELD -> props.opt(arg)
                PopMode.AREA -> g?.let { area(it) }
                PopMode.LENGTH -> g?.let { length(it) }
                PopMode.X -> g?.let { center(it)?.get(0) }
                PopMode.Y -> g?.let { center(it)?.get(1) }
            }
            props.put(field.name, coerce(field.type, v))
        }
        return o.toString()
    }
}
