package com.geolite.app.data

enum class FieldType { TEXT, INTEGER, DOUBLE }
data class Field(val name: String, val type: FieldType)

/**
 * One map layer. geojson is the FeatureCollection (every feature has a string "id" like "f12").
 * geometryType: Point | LineString | Polygon | Mixed (Multi* is folded into its base type).
 */
data class GeoLayer(
    val id: String,
    val name: String,
    val geojson: String,
    val visible: Boolean = true,
    val color: Int = 0xFF1F6F4A.toInt(),
    val geometryType: String = "Mixed",
    val fields: List<Field> = emptyList(),
)
