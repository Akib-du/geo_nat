package com.geolite.app.data

import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

data class Basemap(val id: String, val name: String, val format: String, val minZoom: Int, val maxZoom: Int)

/**
 * Serves raster MBTiles over http://127.0.0.1:<port>/<id>/{z}/{x}/{y} so MapLibre can use them
 * as an ordinary raster tile source, fully offline. MBTiles stores rows in TMS order, so y is flipped.
 */
object MbtilesServer {
    private val dbs = ConcurrentHashMap<String, Pair<SQLiteDatabase, String>>() // id -> (db, mime)
    private var socket: ServerSocket? = null

    /** Opens the file, validates it, and starts the server if needed. Throws if unsupported. */
    @Synchronized
    fun register(id: String, name: String, file: File): Basemap {
        val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val meta = HashMap<String, String>()
            db.rawQuery("SELECT name, value FROM metadata", null).use { c ->
                while (c.moveToNext()) meta[c.getString(0)] = c.getString(1) ?: ""
            }
            val format = (meta["format"] ?: "png").lowercase()
            require(format in setOf("png", "jpg", "jpeg", "webp")) {
                "Only raster MBTiles are supported for now (this one is '$format')"
            }
            val mime = if (format == "png") "image/png" else if (format == "webp") "image/webp" else "image/jpeg"
            dbs[id]?.first?.close()
            dbs[id] = db to mime
            start()
            return Basemap(id, meta["name"]?.takeIf { it.isNotBlank() } ?: name, format,
                meta["minzoom"]?.toIntOrNull() ?: 0, meta["maxzoom"]?.toIntOrNull() ?: 18)
        } catch (t: Throwable) { db.close(); throw t }
    }

    @Synchronized
    fun unregister(id: String) { dbs.remove(id)?.first?.close() }

    fun urlTemplate(id: String) = "http://127.0.0.1:${socket!!.localPort}/$id/{z}/{x}/{y}"

    @Synchronized
    private fun start() {
        if (socket != null) return
        val s = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1")).also { socket = it }
        thread(isDaemon = true, name = "mbtiles-accept") {
            while (true) {
                val c = try { s.accept() } catch (e: Exception) { break }
                thread(isDaemon = true) { runCatching { handle(c) } }
            }
        }
    }

    private fun handle(c: Socket) = c.use {
        val reader = it.getInputStream().bufferedReader()
        val request = reader.readLine() ?: return
        while (true) { val h = reader.readLine(); if (h.isNullOrEmpty()) break }   // drain headers
        val out = it.getOutputStream()
        val p = request.split(" ").getOrNull(1)?.trim('/')?.split('/') ?: return notFound(out)
        if (p.size < 4) return notFound(out)
        val (db, mime) = dbs[p[0]] ?: return notFound(out)
        val z = p[1].toIntOrNull(); val x = p[2].toIntOrNull(); val y = p[3].substringBefore('.').toIntOrNull()
        if (z == null || x == null || y == null) return notFound(out)
        val tmsY = (1 shl z) - 1 - y
        val data = db.rawQuery(
            "SELECT tile_data FROM tiles WHERE zoom_level=? AND tile_column=? AND tile_row=?",
            arrayOf("$z", "$x", "$tmsY")
        ).use { cur -> if (cur.moveToFirst()) cur.getBlob(0) else null } ?: return notFound(out)
        val gz = data.size > 2 && data[0] == 0x1f.toByte() && data[1] == 0x8b.toByte()
        val head = "HTTP/1.1 200 OK\r\nContent-Type: $mime\r\nContent-Length: ${data.size}\r\n" +
            (if (gz) "Content-Encoding: gzip\r\n" else "") + "Connection: close\r\n\r\n"
        out.write(head.toByteArray()); out.write(data); out.flush()
    }

    private fun notFound(out: java.io.OutputStream) {
        out.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray()); out.flush()
    }
}
