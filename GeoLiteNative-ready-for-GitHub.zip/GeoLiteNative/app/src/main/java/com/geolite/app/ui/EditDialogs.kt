package com.geolite.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.geolite.app.data.*

@Composable
fun <T> Choice(items: List<T>, selected: T?, label: (T) -> String, onSelect: (T) -> Unit) {
    Column {
        items.forEach { item ->
            Row(Modifier.fillMaxWidth().clickable { onSelect(item) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(item == selected, { onSelect(item) })
                Text(label(item))
            }
        }
    }
}

@Composable
fun CreateLayerDialog(onCreate: (String, String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var gt by remember { mutableStateOf("Point") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Create feature class") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                Text("Geometry type", style = MaterialTheme.typography.labelMedium)
                Choice(listOf("Point", "LineString", "Polygon"), gt, { it }) { gt = it }
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(name.trim(), gt) }, enabled = name.isNotBlank()) { Text("Create") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun AddFieldDialog(onAdd: (Field) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(FieldType.TEXT) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Add field") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("Field name") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                Choice(FieldType.values().toList(), type, { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }) { type = it }
            }
        },
        confirmButton = { TextButton(onClick = { onAdd(Field(name.trim(), type)) }, enabled = name.isNotBlank()) { Text("Add") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun PopulateDialog(layer: GeoLayer, selectedCount: Int, onRun: (Field, PopMode, String, Boolean) -> Unit, onDismiss: () -> Unit) {
    var field by remember { mutableStateOf<Field?>(null) }
    var mode by remember { mutableStateOf(PopMode.CONSTANT) }
    var arg by remember { mutableStateOf("") }
    var src by remember { mutableStateOf<Field?>(null) }
    var onlySel by remember { mutableStateOf(selectedCount > 0) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Populate field") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (layer.fields.isEmpty()) Text("This layer has no fields yet. Add a field first.")
                Text("Target field", style = MaterialTheme.typography.labelMedium)
                Choice(layer.fields, field, { "${it.name} (${it.type.name.lowercase()})" }) { field = it }
                Spacer(Modifier.height(8.dp))
                Text("Fill with", style = MaterialTheme.typography.labelMedium)
                Choice(PopMode.values().toList(), mode, { it.label }) { mode = it }
                if (mode == PopMode.CONSTANT) OutlinedTextField(arg, { arg = it }, label = { Text("Value") }, singleLine = true)
                if (mode == PopMode.COPY_FIELD) Choice(layer.fields, src, { it.name }) { src = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(onlySel, { onlySel = it }, enabled = selectedCount > 0)
                    Text("Selected features only ($selectedCount)")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { field?.let { onRun(it, mode, if (mode == PopMode.COPY_FIELD) src?.name ?: "" else arg, onlySel && selectedCount > 0) } },
                enabled = field != null && (mode != PopMode.COPY_FIELD || src != null)) { Text("Run") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

private fun show(v: Any?) = if (v == null || v == org.json.JSONObject.NULL) "" else v.toString()

/** Full-screen attribute table. Tap a cell to edit it; tick rows to select them (shared with the map selection). */
@Composable
fun AttributeTable(
    layer: GeoLayer, selected: Set<String>,
    onToggle: (String) -> Unit, onSelectAll: () -> Unit, onSetValue: (String, Field, String) -> Unit,
    onAddField: () -> Unit, onPopulate: () -> Unit, onDeleteSelected: () -> Unit, onClose: () -> Unit,
) {
    val rows = remember(layer.geojson) { FeatureOps.rows(layer.geojson) }
    val scroll = rememberScrollState()
    var editing by remember { mutableStateOf<Pair<String, Field>?>(null) }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column {
                Text("${layer.name}  (${rows.size} features)", Modifier.padding(12.dp), style = MaterialTheme.typography.titleMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
                    TextButton(onAddField) { Text("Add field") }
                    TextButton(onPopulate) { Text("Populate") }
                    TextButton(onSelectAll) { Text("Select all") }
                    TextButton(onDeleteSelected, enabled = selected.isNotEmpty()) { Text("Delete selected (${selected.size})") }
                    TextButton(onClose) { Text("Close") }
                }
                HorizontalDivider()
                Row(Modifier.horizontalScroll(scroll)) {
                    Spacer(Modifier.width(48.dp))
                    layer.fields.forEach { Text(it.name, Modifier.width(130.dp).padding(4.dp), fontWeight = FontWeight.Bold, maxLines = 1) }
                }
                HorizontalDivider()
                LazyColumn(Modifier.weight(1f)) {
                    items(rows, key = { it.first }) { (fid, props) ->
                        Row(Modifier.horizontalScroll(scroll), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(fid in selected, { onToggle(fid) }, Modifier.width(48.dp))
                            layer.fields.forEach { f ->
                                Text(show(props.opt(f.name)), Modifier.width(130.dp).clickable { editing = fid to f }.padding(4.dp), maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { (fid, f) ->
        val current = rows.firstOrNull { it.first == fid }?.second?.opt(f.name)
        var text by remember(fid, f.name) { mutableStateOf(show(current)) }
        AlertDialog(
            onDismissRequest = { editing = null }, title = { Text(f.name) },
            text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text(f.type.name.lowercase()) }) },
            confirmButton = { TextButton({ onSetValue(fid, f, text); editing = null }) { Text("Save") } },
            dismissButton = { TextButton({ editing = null }) { Text("Cancel") } },
        )
    }
}
