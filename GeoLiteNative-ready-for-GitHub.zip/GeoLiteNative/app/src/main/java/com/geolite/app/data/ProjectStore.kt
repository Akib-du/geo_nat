package com.geolite.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ProjectState(
    val layers: List<GeoLayer> = emptyList(),
    val basemaps: List<Basemap> = emptyList(),
    /** null = no basemap, "osm" = OpenStreetMap (online), otherwise a Basemap.id */
    val activeBasemap: String? = null,
)

/**
 * Persists the project under filesDir/project:
 *   project.json        index: layer metadata, basemap list, active basemap
 *   layers/<id>.geojson layer data (rewritten whenever it changes)
 *   basemaps/<id>.mbtiles copied MBTiles files
 */
class ProjectStore(filesDir: File) {
    private val dir = File(filesDir, "project").apply { mkdirs() }
    private val layerDir = File(dir, "layers").apply { mkdirs() }
    val basemapDir = File(dir, "basemaps").apply { mkdirs() }
    private val index = File(dir, "project.json")
    private val written = HashMap<String, Int>()

    fun basemapFile(id: String) = File(basemapDir, "$id.mbtiles")

    @Synchronized
    fun save(s: ProjectState) {
        s.layers.forEach { l ->
            val f = File(layerDir, "${l.id}.geojson")
            if (!f.exists() || written[l.id] != l.geojson.hashCode()) { atomicWrite(f, l.geojson); written[l.id] = l.geojson.hashCode() }
        }
        val keep = s.layers.map { "${it.id}.geojson" }.toSet()
        layerDir.listFiles()?.filter { it.name !in keep }?.forEach { it.delete() }
        val keepMb = s.basemaps.map { "${it.id}.mbtiles" }.toSet()
        basemapDir.listFiles()?.filter { it.name !in keepMb }?.forEach { it.delete() }

        val root = JSONObject()
            .put("active", s.activeBasemap ?: JSONObject.NULL)
            .put("layers", JSONArray(s.layers.map {
                JSONObject().put("id", it.id).put("name", it.name).put("visible", it.visible).put("color", it.color)
                    .put("gtype", it.geometryType)
                    .put("fields", JSONArray(it.fields.map { fl -> JSONObject().put("n", fl.name).put("t", fl.type.name) }))
            }))
            .put("basemaps", JSONArray(s.basemaps.map {
                JSONObject().put("id", it.id).put("name", it.name).put("format", it.format)
                    .put("min", it.minZoom).put("max", it.maxZoom)
            }))
        atomicWrite(index, root.toString())
    }

    @Synchronized
    fun load(): ProjectState = runCatching {
        if (!index.exists()) return ProjectState()
        val root = JSONObject(index.readText())
        val layers = root.getJSONArray("layers").let { a ->
            (0 until a.length()).mapNotNull { i ->
                val o = a.getJSONObject(i)
                val f = File(layerDir, "${o.getString("id")}.geojson")
                if (!f.exists()) null else {
                    val geo = FeatureOps.prepare(f.readText())
                    val fl = o.optJSONArray("fields")?.let { arr ->
                        (0 until arr.length()).map { j -> arr.getJSONObject(j).let { Field(it.getString("n"), FieldType.valueOf(it.getString("t"))) } }
                    } ?: FeatureOps.inferFields(geo)
                    GeoLayer(o.getString("id"), o.getString("name"), geo, o.optBoolean("visible", true),
                        o.optInt("color", 0xFF1F6F4A.toInt()), o.optString("gtype", "").ifEmpty { FeatureOps.inferGeometryType(geo) }, fl)
                }
            }
        }
        val basemaps = root.getJSONArray("basemaps").let { a ->
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Basemap(o.getString("id"), o.getString("name"), o.optString("format", "png"), o.optInt("min", 0), o.optInt("max", 18))
            }
        }.filter { basemapFile(it.id).exists() }
        ProjectState(layers, basemaps, if (root.isNull("active")) null else root.getString("active"))
    }.getOrDefault(ProjectState())

    private fun atomicWrite(f: File, text: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text); tmp.renameTo(f)
    }
}
