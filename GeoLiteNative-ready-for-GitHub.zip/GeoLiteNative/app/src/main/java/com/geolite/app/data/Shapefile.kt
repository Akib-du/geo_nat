package com.geolite.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipInputStream

/** geographic: true = GEOGCS .prj, false = projected CRS, null = no .prj */
class ShapefileResult(val geojson: String, val geographic: Boolean?)

/** Pure-Kotlin shapefile reader (point, multipoint, polyline, polygon, incl. Z/M variants; XY only). */
object Shapefile {
    fun readZip(input: InputStream): ShapefileResult {
        var shp: ByteArray? = null; var dbf: ByteArray? = null; var prj: String? = null
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val n = e.name.lowercase()
                if (n.endsWith(".shp") && shp == null) shp = z.readBytes()
                else if (n.endsWith(".dbf") && dbf == null) dbf = z.readBytes()
                else if (n.endsWith(".prj") && prj == null) prj = z.readBytes().toString(Charsets.UTF_8)
                e = z.nextEntry
            }
        }
        val s = shp ?: error("No .shp file found in the zip")
        return ShapefileResult(parse(s, dbf), prj?.trimStart()?.startsWith("GEOGCS", true))
    }

    fun parse(shp: ByteArray, dbf: ByteArray?): String {
        val attrs = dbf?.let { readDbf(it) }
        val b = ByteBuffer.wrap(shp)
        val feats = JSONArray()
        var pos = 100; var idx = 0
        while (pos + 8 <= shp.size) {
            b.order(ByteOrder.BIG_ENDIAN)
            val len = b.getInt(pos + 4) * 2
            val start = pos + 8
            pos = start + len
            if (len < 4 || pos > shp.size) break
            b.order(ByteOrder.LITTLE_ENDIAN)
            feats.put(JSONObject().put("type", "Feature")
                .put("properties", attrs?.getOrNull(idx) ?: JSONObject())
                .put("geometry", readGeom(b, start) ?: JSONObject.NULL))
            idx++
        }
        return JSONObject().put("type", "FeatureCollection").put("features", feats).toString()
    }

    private fun readGeom(b: ByteBuffer, s: Int): JSONObject? {
        fun pt(x: Double, y: Double) = JSONArray().put(x).put(y)
        return when (val type = b.getInt(s)) {
            1, 11, 21 -> JSONObject().put("type", "Point").put("coordinates", pt(b.getDouble(s + 4), b.getDouble(s + 12)))
            8, 18, 28 -> {
                val n = b.getInt(s + 36)
                val arr = JSONArray(); for (i in 0 until n) arr.put(pt(b.getDouble(s + 40 + 16 * i), b.getDouble(s + 48 + 16 * i)))
                JSONObject().put("type", "MultiPoint").put("coordinates", arr)
            }
            3, 13, 23, 5, 15, 25 -> {
                val nParts = b.getInt(s + 36); val nPts = b.getInt(s + 40)
                val partsAt = s + 44; val ptsAt = partsAt + 4 * nParts
                val rings = (0 until nParts).map { p ->
                    val from = b.getInt(partsAt + 4 * p)
                    val to = if (p + 1 < nParts) b.getInt(partsAt + 4 * (p + 1)) else nPts
                    (from until to).map { i -> doubleArrayOf(b.getDouble(ptsAt + 16 * i), b.getDouble(ptsAt + 16 * i + 8)) }
                }
                if (type == 3 || type == 13 || type == 23) {
                    if (rings.size == 1) JSONObject().put("type", "LineString").put("coordinates", ringJson(rings[0]))
                    else JSONObject().put("type", "MultiLineString").put("coordinates", JSONArray(rings.map { ringJson(it) }))
                } else {
                    // Shapefile outer rings are clockwise (negative area); holes follow their outer ring.
                    val groups = ArrayList<MutableList<List<DoubleArray>>>()
                    for (r in rings) {
                        if (r.size < 4) continue
                        if (area(r) <= 0 || groups.isEmpty()) groups.add(mutableListOf(r)) else groups.last().add(r)
                    }
                    if (groups.isEmpty()) null
                    else if (groups.size == 1) JSONObject().put("type", "Polygon").put("coordinates", JSONArray(groups[0].map { ringJson(it) }))
                    else JSONObject().put("type", "MultiPolygon").put("coordinates", JSONArray(groups.map { g -> JSONArray(g.map { ringJson(it) }) }))
                }
            }
            else -> null
        }
    }

    private fun ringJson(r: List<DoubleArray>) = JSONArray(r.map { JSONArray().put(it[0]).put(it[1]) })
    private fun area(r: List<DoubleArray>): Double {
        var a = 0.0
        for (i in 0 until r.size - 1) a += r[i][0] * r[i + 1][1] - r[i + 1][0] * r[i][1]
        return a / 2
    }

    private class F(val name: String, val type: Char, val len: Int)

    private fun readDbf(d: ByteArray): List<JSONObject> {
        val b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        val n = b.getInt(4); val hdr = b.getShort(8).toInt() and 0xFFFF; val recLen = b.getShort(10).toInt() and 0xFFFF
        val fields = ArrayList<F>(); var p = 32
        while (p + 32 <= hdr && d[p] != 0x0D.toByte()) {
            fields += F(String(d, p, 11, Charsets.US_ASCII).trimEnd('\u0000', ' '), d[p + 11].toInt().toChar(), d[p + 16].toInt() and 0xFF)
            p += 32
        }
        val out = ArrayList<JSONObject>(n)
        for (r in 0 until n) {
            var o = hdr + r * recLen + 1            // skip deletion flag (deleted rows still own a shape)
            if (hdr + (r + 1) * recLen > d.size) break
            val obj = JSONObject()
            for (f in fields) {
                val s = String(d, o, f.len, Charsets.UTF_8).trim(); o += f.len
                obj.put(f.name, when (f.type) {
                    'N', 'F' -> s.toLongOrNull() ?: s.toDoubleOrNull() ?: JSONObject.NULL
                    'L' -> if (s.isEmpty() || s == "?") JSONObject.NULL else s.uppercase() in listOf("Y", "T")
                    else -> s
                })
            }
            out += obj
        }
        return out
    }
}
