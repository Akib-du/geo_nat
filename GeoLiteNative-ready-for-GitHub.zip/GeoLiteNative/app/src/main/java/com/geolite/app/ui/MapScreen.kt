package com.geolite.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.RectF
import android.location.Location
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.geolite.app.data.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.*
import org.maplibre.android.style.layers.Property.NONE
import org.maplibre.android.style.layers.Property.VISIBLE
import org.maplibre.android.style.layers.PropertyFactory.*
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.android.style.sources.RasterSource
import org.maplibre.android.style.sources.TileSet
import org.maplibre.geojson.FeatureCollection
import kotlin.math.hypot

private const val BLANK_STYLE = """{"version":8,"sources":{},"layers":[{"id":"bg","type":"background","paint":{"background-color":"#eef2f0"}}]}"""
private const val OSM_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
private const val IMAGERY_URL = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
private const val BASE_LAYER = "base-layer"

private enum class Tool { NONE, IDENTIFY, SELECT, PLACEMARK, DRAW, MODIFY }
private data class BaseSpec(val key: String, val url: String, val minZoom: Float, val maxZoom: Float)
private data class Sel(val layerId: String, val fid: String)
private val lastGeo = HashMap<String, Int>()   // layer id -> hash of GeoJSON last pushed to the map

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(vm: MapViewModel = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by vm.state.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    var panelOpen by remember { mutableStateOf(false) }
    var fabOpen by remember { mutableStateOf(false) }
    var map by remember { mutableStateOf<MapLibreMap?>(null) }
    var tool by remember { mutableStateOf(Tool.NONE) }
    var selected by remember { mutableStateOf<List<Sel>>(emptyList()) }
    var identify by remember { mutableStateOf<List<Sel>?>(null) }
    var editLayerId by remember { mutableStateOf<String?>(null) }
    var dialog by remember { mutableStateOf("") }
    var sketch by remember { mutableStateOf<List<DoubleArray>>(emptyList()) }
    var modFid by remember { mutableStateOf<String?>(null) }
    var modVertex by remember { mutableStateOf<Int?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val editLayer = state.layers.firstOrNull { it.id == editLayerId }

    fun toast(s: String) { scope.launch { snackbar.showSnackbar(s) } }
    fun setTool(t: Tool) { tool = t; sketch = emptyList(); modFid = null; modVertex = null }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(vm::import) }

    fun placeAtMyLocation() = getFix(ctx) { loc ->
        if (loc == null) toast("Couldn't get a location fix. Is location turned on?")
        else {
            vm.addPlacemark(loc.longitude, loc.latitude)
            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(loc.latitude, loc.longitude), 16.0))
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) placeAtMyLocation() else toast("Location permission denied")
    }
    fun requestPlacemarkHere() {
        if (hasLocationPermission(ctx)) placeAtMyLocation()
        else permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    fun finishSketch() {
        val lay = editLayer ?: return
        val geom: JSONObject? = when {
            lay.geometryType == "LineString" && sketch.size >= 2 ->
                JSONObject().put("type", "LineString").put("coordinates", JSONArray(sketch.map { JSONArray().put(it[0]).put(it[1]) }))
            lay.geometryType == "Polygon" && sketch.size >= 3 -> {
                val ring = JSONArray(sketch.map { JSONArray().put(it[0]).put(it[1]) }).put(JSONArray().put(sketch[0][0]).put(sketch[0][1]))
                JSONObject().put("type", "Polygon").put("coordinates", JSONArray().put(ring))
            }
            else -> null
        }
        if (geom == null) toast("Add more vertices first") else { vm.addFeature(lay.id, geom); sketch = emptyList() }
    }

    // Vertices/sketch shown on the map for the Draw and Modify tools
    val sketchPts: List<DoubleArray> = remember(tool, sketch, modFid, editLayer?.geojson) {
        when (tool) {
            Tool.DRAW -> sketch
            Tool.MODIFY -> modFid?.let { fid ->
                editLayer?.let { l -> FeatureOps.getMany(l.geojson, listOf(fid)).firstOrNull()?.optJSONObject("geometry")?.let(FeatureOps::vertices) }
            } ?: emptyList()
            else -> emptyList()
        }
    }

    // ---- map taps ----
    val handleTap: (LatLng) -> Boolean = tap@{ ll ->
        val m = map ?: return@tap false
        val density = ctx.resources.displayMetrics.density
        when (tool) {
            Tool.NONE -> false
            Tool.PLACEMARK -> { vm.addPlacemark(ll.longitude, ll.latitude); setTool(Tool.NONE); true }
            Tool.IDENTIFY -> { identify = queryAt(m, state.layers, ll, density); true }
            Tool.SELECT -> { selected = queryAt(m, state.layers, ll, density); toast("${selected.size} feature(s) selected"); true }
            Tool.DRAW -> {
                val lay = editLayer
                if (lay == null) toast("Pick an edit layer first")
                else if (lay.geometryType == "Point") vm.addFeature(lay.id, JSONObject().put("type", "Point").put("coordinates", JSONArray().put(ll.longitude).put(ll.latitude)))
                else sketch = sketch + doubleArrayOf(ll.longitude, ll.latitude)
                true
            }
            Tool.MODIFY -> {
                val lay = editLayer
                if (lay == null) { toast("Pick an edit layer first"); return@tap true }
                val fid = modFid
                val vertex = modVertex
                if (fid != null && vertex != null) {                      // step 3: drop the picked vertex here
                    vm.moveVertex(lay.id, fid, vertex, ll.longitude, ll.latitude); modVertex = null
                } else {
                    val tapPx = m.projection.toScreenLocation(ll)
                    var best = -1; var bestD = 28f * density
                    sketchPts.forEachIndexed { i, v ->                    // step 2: pick a vertex of the chosen feature
                        val p = m.projection.toScreenLocation(LatLng(v[1], v[0]))
                        val d = hypot(p.x - tapPx.x, p.y - tapPx.y); if (d < bestD) { bestD = d; best = i }
                    }
                    if (fid != null && best >= 0) modVertex = best
                    else {                                                // step 1: choose a feature of the edit layer
                        val hit = queryAt(m, listOf(lay), ll, density).firstOrNull()
                        modFid = hit?.fid; selected = listOfNotNull(hit)
                        if (hit == null) toast("Tap a feature of ${lay.name}")
                    }
                }
                true
            }
        }
    }
    val tapRef by rememberUpdatedState(handleTap)
    DisposableEffect(map) {
        val m = map
        val l = MapLibreMap.OnMapClickListener { ll -> tapRef(ll) }
        m?.addOnMapClickListener(l)
        onDispose { m?.removeOnMapClickListener(l) }
    }

    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.clearMessage() } }
    LaunchedEffect(map, state, selected, sketchPts, modVertex, tool) {
        map?.getStyle { syncStyle(it, state, selected, sketchPts, tool == Tool.DRAW, editLayer?.geometryType == "Polygon", modVertex) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            Box {
                FloatingActionButton(onClick = { fabOpen = true }) { Icon(Icons.Default.PinDrop, "Add placemark") }
                DropdownMenu(fabOpen, { fabOpen = false }) {
                    DropdownMenuItem(text = { Text("At my location") }, onClick = { fabOpen = false; requestPlacemarkHere() })
                    DropdownMenuItem(text = { Text("At map center") }, onClick = {
                        fabOpen = false; map?.cameraPosition?.target?.let { vm.addPlacemark(it.longitude, it.latitude) } })
                    DropdownMenuItem(text = { Text("Tap on map…") }, onClick = { fabOpen = false; setTool(Tool.PLACEMARK) })
                }
            }
        },
        topBar = {
            TopAppBar(title = {}, actions = {
                MenuButton("Map") { close ->
                    var sub by remember { mutableStateOf("root") }
                    when (sub) {
                        "root" -> {
                            DropdownMenuItem(text = { Text("Add data  ▸") }, onClick = { sub = "add" })
                            DropdownMenuItem(text = { Text("Basemap  ▸") }, onClick = { sub = "base" })
                            DropdownMenuItem(text = { Text("Identify") }, onClick = { setTool(Tool.IDENTIFY); close() })
                            DropdownMenuItem(text = { Text("Select") }, onClick = { setTool(Tool.SELECT); close() })
                            DropdownMenuItem(text = { Text("Clear selection") }, onClick = { selected = emptyList(); close() })
                        }
                        "add" -> {
                            DropdownMenuItem(text = { Text("‹ Back") }, onClick = { sub = "root" })
                            DropdownMenuItem(text = { Text("Shapefile (.zip or .shp)") }, onClick = { close(); picker.launch(arrayOf("*/*")) })
                            DropdownMenuItem(text = { Text("GPX") }, onClick = { close(); picker.launch(arrayOf("*/*")) })
                            DropdownMenuItem(text = { Text("GeoJSON") }, onClick = { close(); picker.launch(arrayOf("*/*")) })
                            DropdownMenuItem(text = { Text("MBTiles basemap") }, onClick = { close(); picker.launch(arrayOf("*/*")) })
                            DropdownMenuItem(text = { Text("GeoTIFF (phase 4)") }, enabled = false, onClick = {})
                            DropdownMenuItem(text = { Text("File Geodatabase (phase 4)") }, enabled = false, onClick = {})
                        }
                        else -> {
                            DropdownMenuItem(text = { Text("‹ Back") }, onClick = { sub = "root" })
                            val check: @Composable (Boolean) -> Unit = { on -> if (on) Icon(Icons.Default.Check, null) }
                            DropdownMenuItem(text = { Text("No basemap") }, trailingIcon = { check(state.activeBasemap == null) }, onClick = { vm.setBasemap(null); close() })
                            DropdownMenuItem(text = { Text("OpenStreetMap") }, trailingIcon = { check(state.activeBasemap == "osm") }, onClick = { vm.setBasemap("osm"); close() })
                            DropdownMenuItem(text = { Text("Imagery") }, trailingIcon = { check(state.activeBasemap == "imagery") }, onClick = { vm.setBasemap("imagery"); close() })
                            state.basemaps.forEach { b ->
                                DropdownMenuItem(text = { Text("${b.name} (offline)") }, trailingIcon = { check(state.activeBasemap == b.id) }, onClick = { vm.setBasemap(b.id); close() })
                            }
                        }
                    }
                }
                MenuButton("Layout") { Planned("Add map frame", "Add map elements (title, legend, scale bar, north arrow)", "Element properties: style, icon, size, position, scale division") }
                MenuButton("Analysis") {
                    Planned("VECTOR TOOLBOX", "Clip", "Buffer", "Merge", "Reprojection",
                        "RASTER TOOLBOX", "Raster calculator", "Raster clip", "Raster to polygon", "Polygon to raster",
                        "CONVERSION TOOLBOX", "Layer to KML", "KML to layer")
                }
                MenuButton("Edit") { close ->
                    var sub by remember { mutableStateOf("root") }
                    if (sub == "layers") {
                        DropdownMenuItem(text = { Text("‹ Back") }, onClick = { sub = "root" })
                        state.layers.forEach { l ->
                            DropdownMenuItem(text = { Text(l.name) }, trailingIcon = { if (l.id == editLayerId) Icon(Icons.Default.Check, null) },
                                onClick = { editLayerId = l.id; setTool(Tool.NONE); sub = "root" })
                        }
                    } else {
                        val has = editLayer != null
                        val canDraw = editLayer?.geometryType in listOf("Point", "LineString", "Polygon")
                        DropdownMenuItem(text = { Text("Edit layer: ${editLayer?.name ?: "none"}  ▸") }, onClick = { sub = "layers" })
                        DropdownMenuItem(text = { Text("Create feature class…") }, onClick = { dialog = "create"; close() })
                        DropdownMenuItem(text = { Text("Add feature") }, enabled = canDraw, onClick = { setTool(Tool.DRAW); close() })
                        DropdownMenuItem(text = { Text("Modify feature (move vertex)") }, enabled = has, onClick = { setTool(Tool.MODIFY); close() })
                        DropdownMenuItem(text = { Text("Attribute table") }, enabled = has, onClick = { dialog = "table"; close() })
                        DropdownMenuItem(text = { Text("Add field…") }, enabled = has, onClick = { dialog = "addfield"; close() })
                        DropdownMenuItem(text = { Text("Populate field…") }, enabled = has && editLayer!!.fields.isNotEmpty(), onClick = { dialog = "populate"; close() })
                        DropdownMenuItem(text = { Text("Delete selected features") }, enabled = has && selected.any { it.layerId == editLayerId }, onClick = { dialog = "delete"; close() })
                    }
                }
                IconButton({ panelOpen = !panelOpen }) { Icon(Icons.Default.Layers, "Layers") }
            })
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            MapLibreView(ctx) { map = it }
            if (panelOpen) Panel(state, vm, Modifier.align(Alignment.TopEnd))
            if (tool != Tool.NONE) {
                Surface(Modifier.align(Alignment.TopCenter).padding(8.dp), shape = MaterialTheme.shapes.medium, tonalElevation = 6.dp) {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(when (tool) {
                            Tool.IDENTIFY -> "Identify: tap a feature"
                            Tool.SELECT -> "Select: tap features"
                            Tool.DRAW -> "Add to ${editLayer?.name}: tap to place vertices (${sketch.size})"
                            Tool.MODIFY -> when { modFid == null -> "Modify: tap a feature"; modVertex == null -> "Tap a vertex to move"; else -> "Tap the new position" }
                            else -> "Tap the map to place a point"
                        })
                        Row {
                            if (tool == Tool.DRAW && editLayer?.geometryType != "Point") {
                                TextButton({ sketch = sketch.dropLast(1) }) { Text("Undo") }
                                TextButton({ finishSketch() }) { Text("Finish") }
                            }
                            TextButton({ setTool(Tool.NONE) }) { Text("Done") }
                        }
                    }
                }
            }
        }
    }

    // ---- dialogs ----
    identify?.let { hits ->
        AlertDialog(
            onDismissRequest = { identify = null },
            confirmButton = { TextButton({ identify = null }) { Text("Close") } },
            title = { Text("Identify") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (hits.isEmpty()) Text("No features at this location.")
                    for (h in hits) {
                        val l = state.layers.firstOrNull { it.id == h.layerId } ?: continue
                        val f = FeatureOps.getMany(l.geojson, listOf(h.fid)).firstOrNull() ?: continue
                        Text("${l.name} · ${f.optJSONObject("geometry")?.optString("type") ?: ""}", style = MaterialTheme.typography.titleSmall)
                        val props = f.optJSONObject("properties")
                        if (props != null) for (k in props.keys()) Text("$k: ${props.opt(k)?.takeIf { it != JSONObject.NULL } ?: ""}")
                        Spacer(Modifier.height(8.dp))
                    }
                }
            },
        )
    }
    when (dialog) {
        "create" -> CreateLayerDialog({ name, gt -> editLayerId = vm.createLayer(name, gt); dialog = "" }, { dialog = "" })
        "addfield" -> editLayer?.let { l -> AddFieldDialog({ vm.addField(l.id, it); dialog = "" }, { dialog = "" }) }
        "populate" -> editLayer?.let { l ->
            val selIds = selected.filter { it.layerId == l.id }.map { it.fid }.toSet()
            PopulateDialog(l, selIds.size, { f, mode, arg, onlySel -> vm.populate(l.id, f, mode, arg, if (onlySel) selIds else null); dialog = "" }, { dialog = "" })
        }
        "delete" -> editLayer?.let { l ->
            val ids = selected.filter { it.layerId == l.id }.map { it.fid }.toSet()
            AlertDialog(onDismissRequest = { dialog = "" }, title = { Text("Delete features") }, text = { Text("Delete ${ids.size} selected feature(s) from ${l.name}? This can't be undone.") },
                confirmButton = { TextButton({ vm.deleteFeatures(l.id, ids); selected = selected.filterNot { it.layerId == l.id }; modFid = null; dialog = "" }) { Text("Delete") } },
                dismissButton = { TextButton({ dialog = "" }) { Text("Cancel") } })
        }
        "table" -> editLayer?.let { l ->
            val ids = selected.filter { it.layerId == l.id }.map { it.fid }.toSet()
            AttributeTable(
                layer = l, selected = ids,
                onToggle = { fid -> val s = Sel(l.id, fid); selected = if (s in selected) selected - s else selected + s },
                onSelectAll = { selected = selected.filterNot { it.layerId == l.id } + FeatureOps.rows(l.geojson).map { Sel(l.id, it.first) } },
                onSetValue = { fid, f, text -> vm.setValue(l.id, fid, f, text) },
                onAddField = { dialog = "addfield" }, onPopulate = { dialog = "populate" },
                onDeleteSelected = { dialog = "delete" }, onClose = { dialog = "" },
            )
        }
    }
}

@Composable
private fun MenuButton(label: String, content: @Composable ColumnScope.(close: () -> Unit) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton({ open = true }) { Text(label) }
        DropdownMenu(open, { open = false }) { content { open = false } }
    }
}

/** Placeholder entries for menus built in later phases. ALL-CAPS strings are section headings. */
@Composable
private fun Planned(vararg items: String) {
    items.forEach { s ->
        if (s == s.uppercase()) Text(s, Modifier.padding(horizontal = 16.dp, vertical = 6.dp), style = MaterialTheme.typography.labelSmall)
        else DropdownMenuItem(text = { Text(s) }, enabled = false, onClick = {})
    }
}

@Composable
private fun Panel(s: ProjectState, vm: MapViewModel, modifier: Modifier) {
    Card(modifier.padding(8.dp).widthIn(max = 340.dp).heightIn(max = 480.dp)) {
        LazyColumn(Modifier.padding(12.dp)) {
            item { Text("Layers", style = MaterialTheme.typography.titleSmall) }
            if (s.layers.isEmpty()) item { Text("No layers yet. Map ▸ Add data.") }
            items(s.layers, key = { "l" + it.id }) { l ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(l.visible, { vm.toggleVisible(l.id) })
                    Text(l.name, Modifier.weight(1f))
                    IconButton({ vm.removeLayer(l.id) }) { Icon(Icons.Default.Delete, "Remove layer") }
                }
            }
            if (s.basemaps.isNotEmpty()) {
                item { HorizontalDivider(Modifier.padding(vertical = 8.dp)); Text("Offline basemaps", style = MaterialTheme.typography.titleSmall) }
                items(s.basemaps, key = { "b" + it.id }) { b ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(b.name, Modifier.weight(1f).padding(start = 12.dp))
                        IconButton({ vm.removeBasemap(b.id) }) { Icon(Icons.Default.Delete, "Remove basemap") }
                    }
                }
            }
        }
    }
}

@Composable
private fun MapLibreView(ctx: Context, onReady: (MapLibreMap) -> Unit) {
    val mapView = remember { MapLibre.getInstance(ctx); MapView(ctx) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, mapView) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> {}
            }
        }
        owner.lifecycle.addObserver(obs)
        mapView.getMapAsync { m ->
            m.setStyle(Style.Builder().fromJson(BLANK_STYLE)) { onReady(m) }
            m.cameraPosition = CameraPosition.Builder().target(LatLng(23.8103, 90.4125)).zoom(5.0).build()
        }
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    AndroidView({ mapView }, Modifier.fillMaxSize())
}

// ---------- location ----------
private fun hasLocationPermission(ctx: Context) =
    listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        .any { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

@SuppressLint("MissingPermission")
private fun getFix(ctx: Context, cb: (Location?) -> Unit) {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val provider = when {
        fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
        lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
        else -> return cb(null)
    }
    try { LocationManagerCompat.getCurrentLocation(lm, provider, null, ContextCompat.getMainExecutor(ctx)) { cb(it) } }
    catch (e: SecurityException) { cb(null) }
}

// ---------- identify / select ----------
/** Features of the given visible layers under the tap, as (layer id, feature id) pairs. */
private fun queryAt(map: MapLibreMap, layers: List<GeoLayer>, ll: LatLng, density: Float): List<Sel> {
    val pt = map.projection.toScreenLocation(ll)
    val r = 12f * density
    val box = RectF(pt.x - r, pt.y - r, pt.x + r, pt.y + r)
    return layers.filter { it.visible }.flatMap { l ->
        val ids = arrayOf("gl-${l.id}:fill", "gl-${l.id}:line", "gl-${l.id}:pt")
        map.queryRenderedFeatures(box, *ids).mapNotNull { it.id() }.distinct().map { Sel(l.id, it) }
    }
}

// ---------- style sync ----------
private fun baseSpec(s: ProjectState): BaseSpec? = when (val a = s.activeBasemap) {
    null -> null
    "osm" -> BaseSpec("osm", OSM_URL, 0f, 19f)
    "imagery" -> BaseSpec("imagery", IMAGERY_URL, 0f, 19f)
    else -> s.basemaps.firstOrNull { it.id == a }?.let {
        BaseSpec(it.id, MbtilesServer.urlTemplate(it.id), it.minZoom.toFloat(), it.maxZoom.toFloat())
    }
}

private fun featureCollection(features: List<JSONObject>) =
    FeatureCollection.fromJson(JSONObject().put("type", "FeatureCollection").put("features", JSONArray(features)).toString())

private fun syncStyle(style: Style, s: ProjectState, selected: List<Sel>, sketchPts: List<DoubleArray>, drawLine: Boolean, closeRing: Boolean, pickedVertex: Int?) {
    // Basemap
    val want = baseSpec(s)
    val wantId = want?.let { "base-src-${it.key}" }
    val have = style.sources.firstOrNull { it.id.startsWith("base-src-") }?.id
    if (have != wantId) {
        if (style.getLayer(BASE_LAYER) != null) style.removeLayer(BASE_LAYER)
        if (have != null) style.removeSource(have)
        if (want != null && wantId != null) {
            val tiles = TileSet("2.2.0", want.url).apply { minZoom = want.minZoom; maxZoom = want.maxZoom }
            style.addSource(RasterSource(wantId, tiles, 256))
            style.addLayerAbove(RasterLayer(BASE_LAYER, wantId), "bg")
        }
    }

    fun geom(vararg t: String) = Expression.any(*t.map { Expression.eq(Expression.geometryType(), it) }.toTypedArray())

    // Selection + sketch layers sit above all data layers (data layers are inserted below "sel-fill").
    if (style.getSource("sel-src") == null) {
        val hi = 0xFFFFEB3B.toInt(); val edge = 0xFFFF6F00.toInt()
        style.addSource(GeoJsonSource("sel-src"))
        style.addLayer(FillLayer("sel-fill", "sel-src").withProperties(fillColor(hi), fillOpacity(0.5f)).withFilter(geom("Polygon", "MultiPolygon")))
        style.addLayer(LineLayer("sel-line", "sel-src").withProperties(lineColor(edge), lineWidth(4f))
            .withFilter(geom("LineString", "MultiLineString", "Polygon", "MultiPolygon")))
        style.addLayer(CircleLayer("sel-pt", "sel-src").withProperties(circleColor(hi), circleRadius(9f), circleStrokeColor(edge), circleStrokeWidth(3f))
            .withFilter(geom("Point", "MultiPoint")))
        style.addSource(GeoJsonSource("sk-src"))
        style.addLayer(LineLayer("sk-line", "sk-src").withProperties(lineColor(0xFF1565C0.toInt()), lineWidth(3f), lineDasharray(arrayOf(2f, 2f)))
            .withFilter(Expression.eq(Expression.geometryType(), "LineString")))
        val isPick = Expression.eq(Expression.get("picked"), Expression.literal(1))
        style.addLayer(CircleLayer("sk-pt", "sk-src").withProperties(circleColor(0xFF1565C0.toInt()), circleRadius(6f), circleStrokeColor(0xFFFFFFFF.toInt()), circleStrokeWidth(2f))
            .withFilter(Expression.all(Expression.eq(Expression.geometryType(), "Point"), Expression.not(isPick))))
        style.addLayer(CircleLayer("sk-pick", "sk-src").withProperties(circleColor(0xFFD32F2F.toInt()), circleRadius(9f), circleStrokeColor(0xFFFFFFFF.toInt()), circleStrokeWidth(2f))
            .withFilter(Expression.all(Expression.eq(Expression.geometryType(), "Point"), isPick)))
    }
    val highlight = selected.groupBy { it.layerId }.flatMap { (lid, sels) ->
        s.layers.firstOrNull { it.id == lid }?.let { FeatureOps.getMany(it.geojson, sels.map { x -> x.fid }) } ?: emptyList()
    }
    style.getSourceAs<GeoJsonSource>("sel-src")?.setGeoJson(featureCollection(highlight))

    val sk = ArrayList<JSONObject>()
    if (drawLine && sketchPts.size >= 2) {
        val pts = if (closeRing && sketchPts.size >= 3) sketchPts + listOf(sketchPts[0]) else sketchPts
        sk.add(JSONObject().put("type", "Feature").put("properties", JSONObject())
            .put("geometry", JSONObject().put("type", "LineString").put("coordinates", JSONArray(pts.map { JSONArray().put(it[0]).put(it[1]) }))))
    }
    sketchPts.forEachIndexed { i, p ->
        sk.add(JSONObject().put("type", "Feature").put("properties", JSONObject().put("picked", if (i == pickedVertex) 1 else 0))
            .put("geometry", JSONObject().put("type", "Point").put("coordinates", JSONArray().put(p[0]).put(p[1]))))
    }
    style.getSourceAs<GeoJsonSource>("sk-src")?.setGeoJson(featureCollection(sk))

    // Data layers
    val keep = s.layers.map { it.id }.toSet()
    style.layers.map { it.id }.filter { it.startsWith("gl-") && it.removePrefix("gl-").substringBefore(':') !in keep }.forEach { style.removeLayer(it) }
    style.sources.map { it.id }.filter { it.startsWith("gs-") && it.removePrefix("gs-") !in keep }.forEach { style.removeSource(it) }

    s.layers.forEach { l ->
        val src = "gs-${l.id}"
        val vis = visibility(if (l.visible) VISIBLE else NONE)
        if (style.getSource(src) == null) {
            style.addSource(GeoJsonSource(src, l.geojson)); lastGeo[l.id] = l.geojson.hashCode()
            style.addLayerBelow(FillLayer("gl-${l.id}:fill", src).withProperties(fillColor(l.color), fillOpacity(0.35f), vis)
                .withFilter(geom("Polygon", "MultiPolygon")), "sel-fill")
            style.addLayerBelow(LineLayer("gl-${l.id}:line", src).withProperties(lineColor(l.color), lineWidth(2f), vis)
                .withFilter(geom("LineString", "MultiLineString", "Polygon", "MultiPolygon")), "sel-fill")
            style.addLayerBelow(CircleLayer("gl-${l.id}:pt", src).withProperties(circleColor(l.color), circleRadius(5f), vis)
                .withFilter(geom("Point", "MultiPoint")), "sel-fill")
        } else {
            if (lastGeo[l.id] != l.geojson.hashCode()) {
                style.getSourceAs<GeoJsonSource>(src)?.setGeoJson(l.geojson); lastGeo[l.id] = l.geojson.hashCode()
            }
            listOf("fill", "line", "pt").forEach { style.getLayer("gl-${l.id}:$it")?.setProperties(vis) }
        }
    }
}
