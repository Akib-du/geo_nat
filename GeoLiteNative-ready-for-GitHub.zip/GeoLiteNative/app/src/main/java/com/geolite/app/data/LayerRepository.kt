package com.geolite.app.data

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Imported(val layer: GeoLayer, val warning: String? = null)

/** Imports files into layers / basemaps. Phase 4 adds GeoTIFF and FileGDB. */
class LayerRepository(private val resolver: ContentResolver, private val store: ProjectStore) {

    fun fileName(uri: Uri): String =
        resolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else null
        } ?: "Layer"

    suspend fun importVector(uri: Uri, fileName: String): Imported = withContext(Dispatchers.IO) {
        val lower = fileName.lowercase(); val base = fileName.substringBeforeLast('.')
        fun open() = resolver.openInputStream(uri)!!
        fun layer(json: String): GeoLayer {
            val p = FeatureOps.prepare(json)
            return GeoLayer(UUID.randomUUID().toString(), base, p, geometryType = FeatureOps.inferGeometryType(p), fields = FeatureOps.inferFields(p))
        }
        when {
            lower.endsWith(".gpx") -> Imported(layer(open().use { Gpx.toGeoJson(it) }))
            lower.endsWith(".zip") -> {
                val r = open().use { Shapefile.readZip(it) }
                Imported(layer(r.geojson), when (r.geographic) {
                    true -> null
                    null -> "No .prj found: assuming lon/lat (WGS84)."
                    false -> "Projected CRS detected. Coordinates will be misplaced until the Reprojection tool is added."
                })
            }
            lower.endsWith(".shp") -> Imported(layer(Shapefile.parse(open().use { it.readBytes() }, null)),
                "Geometry only. Pick a .zip containing the .dbf to get attributes.")
            lower.endsWith(".json") || lower.endsWith(".geojson") -> {
                val text = open().bufferedReader().use { it.readText() }
                Imported(layer(when (JSONObject(text).getString("type")) {
                    "FeatureCollection" -> text
                    "Feature" -> """{"type":"FeatureCollection","features":[$text]}"""
                    else -> """{"type":"FeatureCollection","features":[{"type":"Feature","properties":{},"geometry":$text}]}"""
                }))
            }
            else -> error("Unsupported file type: $fileName")
        }
    }

    /** Copies the MBTiles file into app storage and validates it. */
    suspend fun importMbtiles(uri: Uri, name: String): Basemap = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val dest: File = store.basemapFile(id)
        try {
            resolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            MbtilesServer.register(id, name.substringBeforeLast('.'), dest)
        } catch (t: Throwable) { dest.delete(); throw t }
    }
}
