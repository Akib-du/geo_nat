package com.geolite.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.geolite.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private const val PLACEMARKS = "placemarks"

class MapViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ProjectStore(app.filesDir)
    private val repo = LayerRepository(app.contentResolver, store)

    private val _state = MutableStateFlow(ProjectState())
    val state: StateFlow<ProjectState> = _state
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    init {
        val saved = store.load()
        val ok = saved.basemaps.filter { b -> runCatching { MbtilesServer.register(b.id, b.name, store.basemapFile(b.id)) }.isSuccess }
        _state.value = saved.copy(
            basemaps = ok,
            activeBasemap = saved.activeBasemap?.takeIf { it == "osm" || it == "imagery" || ok.any { b -> b.id == it } },
        )
    }

    fun import(uri: Uri) = viewModelScope.launch {
        val name = repo.fileName(uri)
        runCatching {
            if (name.endsWith(".mbtiles", true)) {
                val b = repo.importMbtiles(uri, name)
                change { it.copy(basemaps = it.basemaps + b, activeBasemap = b.id) }
            } else {
                val r = repo.importVector(uri, name)
                change { it.copy(layers = it.layers + r.layer) }
                r.warning?.let { _message.value = it }
            }
        }.onFailure { _message.value = "Import failed: ${it.message}" }
    }

    // ---------- placemarks ----------
    fun addPlacemark(lon: Double, lat: Double) = change { s ->
        val base = s.layers.firstOrNull { it.id == PLACEMARKS } ?: GeoLayer(PLACEMARKS, "Placemarks", FeatureOps.EMPTY, true, 0xFFD32F2F.toInt(), "Point",
            listOf(Field("name", FieldType.TEXT), Field("lon", FieldType.DOUBLE), Field("lat", FieldType.DOUBLE), Field("created", FieldType.TEXT)))
        val props = JSONObject().put("name", "Placemark ${FeatureOps.count(base.geojson) + 1}").put("lon", lon).put("lat", lat)
            .put("created", java.time.Instant.now().toString())
        val geom = JSONObject().put("type", "Point").put("coordinates", JSONArray().put(lon).put(lat))
        val updated = base.copy(geojson = FeatureOps.addFeature(base.geojson, geom, props))
        s.copy(layers = if (s.layers.any { it.id == PLACEMARKS }) s.layers.map { if (it.id == PLACEMARKS) updated else it } else s.layers + updated)
    }

    // ---------- editing ----------
    private fun editLayer(id: String, f: (GeoLayer) -> GeoLayer) = change { s -> s.copy(layers = s.layers.map { if (it.id == id) f(it) else it }) }

    fun createLayer(name: String, geometryType: String): String {
        val l = GeoLayer(UUID.randomUUID().toString(), name, FeatureOps.EMPTY, geometryType = geometryType)
        change { it.copy(layers = it.layers + l) }
        return l.id
    }

    fun addField(layerId: String, field: Field) {
        val l = _state.value.layers.firstOrNull { it.id == layerId } ?: return
        if (!Regex("[A-Za-z_][A-Za-z0-9_]{0,30}").matches(field.name)) { _message.value = "Field names: letters, digits, underscore; max 31 chars"; return }
        if (l.fields.any { it.name.equals(field.name, true) }) { _message.value = "That field already exists"; return }
        editLayer(layerId) { it.copy(geojson = FeatureOps.addField(it.geojson, field), fields = it.fields + field) }
    }

    fun setValue(layerId: String, fid: String, field: Field, text: String) =
        editLayer(layerId) { it.copy(geojson = FeatureOps.setValue(it.geojson, fid, field, text)) }

    fun populate(layerId: String, field: Field, mode: PopMode, arg: String, ids: Set<String>?) =
        editLayer(layerId) { it.copy(geojson = FeatureOps.populate(it.geojson, field, mode, arg, ids)) }

    fun deleteFeatures(layerId: String, ids: Set<String>) =
        editLayer(layerId) { it.copy(geojson = FeatureOps.delete(it.geojson, ids)) }

    fun addFeature(layerId: String, geometry: JSONObject) =
        editLayer(layerId) { it.copy(geojson = FeatureOps.addFeature(it.geojson, geometry, FeatureOps.blankProps(it.fields))) }

    fun moveVertex(layerId: String, fid: String, index: Int, lon: Double, lat: Double) =
        editLayer(layerId) { it.copy(geojson = FeatureOps.moveVertex(it.geojson, fid, index, lon, lat)) }

    // ---------- layers / basemaps ----------
    fun toggleVisible(id: String) = change { s -> s.copy(layers = s.layers.map { if (it.id == id) it.copy(visible = !it.visible) else it }) }
    fun removeLayer(id: String) = change { s -> s.copy(layers = s.layers.filterNot { it.id == id }) }
    fun setBasemap(key: String?) = change { it.copy(activeBasemap = key) }
    fun removeBasemap(id: String) {
        MbtilesServer.unregister(id)
        change { s -> s.copy(basemaps = s.basemaps.filterNot { it.id == id }, activeBasemap = if (s.activeBasemap == id) null else s.activeBasemap) }
    }
    fun clearMessage() { _message.value = null }

    private fun change(f: (ProjectState) -> ProjectState) {
        _state.update(f)
        val snapshot = _state.value
        viewModelScope.launch(Dispatchers.IO) { runCatching { store.save(snapshot) } }
    }
}
