package com.geolite.app.data

import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream

/** GPX -> GeoJSON FeatureCollection. Waypoints become points; tracks and routes become lines. */
object Gpx {
    fun toGeoJson(input: InputStream): String {
        val p = Xml.newPullParser()
        p.setInput(input, null)
        val feats = JSONArray()
        var kind: String? = null; var name = ""; var desc = ""; var inPt = false
        var lat = 0.0; var lon = 0.0; var text = ""
        var segs = ArrayList<JSONArray>(); var cur: JSONArray? = null

        fun feature(type: String, geom: JSONObject) = feats.put(
            JSONObject().put("type", "Feature").put("geometry", geom)
                .put("properties", JSONObject().put("name", name).put("desc", desc).put("type", type)))

        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    text = ""
                    when (p.name) {
                        "wpt" -> { kind = "wpt"; name = ""; desc = ""
                            lat = p.getAttributeValue(null, "lat").toDouble(); lon = p.getAttributeValue(null, "lon").toDouble() }
                        "trk", "rte" -> { kind = p.name; name = ""; desc = ""; segs = ArrayList()
                            cur = if (kind == "rte") JSONArray().also { segs.add(it) } else null }
                        "trkseg" -> cur = JSONArray().also { segs.add(it) }
                        "trkpt", "rtept" -> { inPt = true
                            lat = p.getAttributeValue(null, "lat").toDouble(); lon = p.getAttributeValue(null, "lon").toDouble() }
                    }
                }
                XmlPullParser.TEXT -> text = p.text.trim()
                XmlPullParser.END_TAG -> when (p.name) {
                    "name" -> if (kind != null && !inPt) name = text
                    "desc" -> if (kind != null && !inPt) desc = text
                    "trkpt", "rtept" -> { cur?.put(JSONArray().put(lon).put(lat)); inPt = false }
                    "wpt" -> { feature("waypoint", JSONObject().put("type", "Point").put("coordinates", JSONArray().put(lon).put(lat))); kind = null }
                    "trk", "rte" -> {
                        val lines = segs.filter { it.length() >= 2 }
                        if (lines.size == 1) feature(if (kind == "rte") "route" else "track",
                            JSONObject().put("type", "LineString").put("coordinates", lines[0]))
                        else if (lines.size > 1) feature("track",
                            JSONObject().put("type", "MultiLineString").put("coordinates", JSONArray(lines)))
                        kind = null
                    }
                }
            }
            ev = p.next()
        }
        return JSONObject().put("type", "FeatureCollection").put("features", feats).toString()
    }
}
